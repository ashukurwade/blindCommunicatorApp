package ar.com.lrusso.blindcommunicator;

public interface EditTextImeBackListener
	{
	public abstract void onImeBack(EditTextBackEvent ctrl, String text);
	}