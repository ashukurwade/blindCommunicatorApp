package ar.com.lrusso.blindcommunicator;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MmsReceiver extends BroadcastReceiver
	{
    @Override public void onReceive(Context context, Intent intent)
    	{
        // TODO: Implement MMS receiver
    	}
	}
