package ar.com.lrusso.blindcommunicator;

import android.app.Activity;

public class ComposeSmsActivity extends Activity
	{
    // TODO: Implement SMS/MMS compose functions and need to respond ACTION_SENDTO Intnet
	}
